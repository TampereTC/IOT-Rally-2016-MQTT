REST example
============

Simple REST example that configures a REST client to talk to www.timeapi.org and then
makes a request every second to get the current time and print it.

This example prints a whole lot more than one would normally given the typical space constraints...

